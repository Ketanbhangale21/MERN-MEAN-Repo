// Importing mongoose module
var mongoose = require("mongoose");

// Connecting to the MongoDB database
mongoose.connect("mongodb://localhost:27017/ExpressApi");

// Defining the schema for Employee collection
var Schema = mongoose.Schema;
const EmployeeSchema = new Schema(
  {
    // Unique identifier for each employee
    empid: String,
    // Name of the employee
    name: String,
    // Email address of the employee
    email: String,
    // Department of the employee
    department: String,
    // Phone number of the employee
    phone: String,
  },
  { versionKey: false }
);

// Creating a model for Employee collection using the defined schema
var EmployeeModel = mongoose.model("Employee", EmployeeSchema, "employee");

// Exporting the EmployeeModel for use in other modules
module.exports = EmployeeModel;
