const express = require("express");
const router = express.Router();
const EmployeeModel = require("./models/employee_model");
router.use(express.json());

// Route to read all employees
router.get("/employee", async function (req, res) {
  // Find all employees in the database, excluding the _id field
  let result = await EmployeeModel.find({}, { _id: 0 })
    .sort({ empid: 1 })
    .lean();
  // console.table(result);
  let employeeId = "";
  try {
    // Log the number of items in the database
    // Send the result as a response
    // res.send(result);
    // res.render("index", { employees: result, employeeId });
    res.send(result);
    // console.log("[Read All] --->  No. of items in Database : ", result.length);
  } catch (error) {
    // If there's an error, send a 500 status code with the error message
    res.status(500).send(error);
  }
});

// Route to read an employee by ID
router.get("/employee/view/:id", async function (req, res) {
  // Find all employees in the database
  // let result = await EmployeeModel.find({}, { _id: 0 });

  // Get the employee ID from the request parameters
  let employeeId = req.params.id;
  //   console.log(employeeId);

  // Filter the result to find the employee with the matching ID
  // let data = result.filter((x) => x.empid == employeeId)[0];
  const data = await EmployeeModel.findOne(
    { empid: employeeId },
    { _id: 0 }
  ).lean();

  if (!data) {
    // If no employee is found with the matching ID, send a 404 status code with a message
    return res.status(404).send("Data is not found  with this id!");
  } else {
    // If an employee is found, log the result and send it as a response
    // res.render("index", { employee: data, employeeId });
    res.send(data);
    console.log(`[Read By Id] --> ${JSON.stringify(data)}`);
  }
});
// POST ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
router.post("/employee", async function (req, res) {
  try {
    // Create a new employee using the EmployeeModel and request body
    const newEmployee = new EmployeeModel({
      empid: req.body.empid,
      name: req.body.name,
      email: req.body.email,
      department: req.body.department,
      phone: req.body.phone,
    });

    // Save the new employee to the database
    // console.log(newEmployee);
    const createdEmployee = await newEmployee.save();

    console.log("created");
    // Send a success response with the created employee data
    // res.status(201).json({
    //   message: "Employee created successfully",
    //   data: createdEmployee,
    // });
  } catch (error) {
    // If there's an error, send a 500 status code with the error message
    res
      .status(500)
      .json({ error: "Internal Server Error", message: error.message });
  } finally {
    let employeeId = "";
    let result = await EmployeeModel.find({}, { _id: 0 }).lean();
    res.render("index", { employees: result, employeeId });
  }
});
//PUT ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
router.put("/employee", async function (req, res) {
  // Find the employee that needs to be updated by its ID from the URL parameter
  // Get the employee ID from the request parameters
  let employeeId = req.body.empid;
  // Find the employee in the database by its ID
  let employee = await EmployeeModel.findOne({ empid: employeeId });
  // console.log(employeeId);
  if (!employee) {
    return res.status(404).json({
      message: `No employee found for id : ${employeeId}`,
    });
  } else {
    // Update the employee fields with the values sent in the PUT request body
    employee.name = req.body.name;
    employee.email = req.body.email;
    employee.department = req.body.department;
    employee.phone = req.body.phone;
    // Save the updated employee to the database
    const updatedEmployee = await employee.save();
    // Send a success response with the updated employee data
    res.status(200).json({
      message: "Employee updated successfully",
      data: updatedEmployee,
    });
  }
});
//DELETE ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

router.delete("/employee/remove/:id", async function (req, res) {
  let employeeId = req.params.id;
  console.log(employeeId);
  try {
    // Find the employee using the ID from the URL parameter
    let employee = await EmployeeModel.findOneAndDelete({
      empid: employeeId,
    });
    // console.log(employee);
    // If no employee is found, send a 404 status code with a message
    if (!employee) {
      res.status(404).json({
        message: "No employee found",
      });
    }
    // res.render("index", { employees: result, employeeId });
    // Otherwise, send a 200 status code and the deleted employee object
    else {
      // Send a success response with the deleted employee object
      res.status(200).json({
        message: "Employee deleted successfully",
        data: employee,
      });
    }

    // employeeId = "";
    // res.render("index", { employees: result, employeeId });
  } catch (err) {
    // If there's an error, send a 500 status code and error message
    res.status(500).json({
      error: "Internal Server Error",
      message: err.message,
    });
  }
});

module.exports = router;
