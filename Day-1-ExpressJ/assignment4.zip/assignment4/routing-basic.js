var Express = require("express");

var app = Express(); //creates express application
app.use(Express.static("Public")); //including static files data images,videos etc

app.get("/", function (req, res) {
  // let dirName = "D:\\CODING\\ExpressApps\\my-projects\\views\\home.html";
  res.sendFile(__dirname + "/views/home.html");
  // console.log(__dirname);
});
app.get("/login", function (req, res) {
  res.sendFile(__dirname + "/views/login.html");
});
var server = app.listen(3005, function () {
  console.log("This is My Express App browse it at : http://localhost:3005/");
});
