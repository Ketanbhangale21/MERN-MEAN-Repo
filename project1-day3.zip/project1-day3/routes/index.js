var express = require("express");
var router = express.Router();

// let dataObj = {};
var products = [
  {
    pid: 1,
    pname: "Product 1",
    price: 10,
    quantity: 20,
    category: "Category1",
  },
  {
    pid: 2,
    pname: "Product 2",
    price: 15,
    quantity: 15,
    category: "Category2",
  },
  {
    pid: 3,
    pname: "Product 3",
    price: 25,
    quantity: 30,
    category: "Category3",
  },
  {
    pid: 4,
    pname: "Product 4",
    price: 12,
    quantity: 25,
    category: "Category2",
  },
  {
    pid: 5,
    pname: "Product 5",
    price: 18,
    quantity: 18,
    category: "Category1",
  },
];

/* GET home page. */
router.get("/", function (req, res, next) {
  res.render("index", { title: "Express" });
});
router.get("/allproducts", function (req, res) {
  res.render("allproducts", { products });
});
router.get("/allproducts/:id", (req, res) => {
  const productId = parseInt(req.params.id);
  const selectedProduct = products.find((product) => product.pid === productId);

  res.render("selectedProduct", { product: selectedProduct });
});

//CATEGORY REQUEST

router.get("/categoryproduct", (req, res) => {
  const selectedCategory = req.query.category;
  const filteredProducts = products.filter(
    (product) => product.category === selectedCategory
  );

  res.render("categoryproduct", {
    products: filteredProducts,
    category: selectedCategory,
  });
});

module.exports = router;
